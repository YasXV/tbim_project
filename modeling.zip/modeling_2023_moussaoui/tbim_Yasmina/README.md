## README pour le programme TBIM:

# Probleme 1 : on trouve 17 atomes pour chaque voisins T_T (Résolu)

Probleme 1 : on trouve 17 atomes pour chaque voisins T_T
<br />
Si le rayon de coupure se situe juste après les 1ers voisins il devrait y en avoir 12 et si vous comptez aussi les 2nds voisins, il devrait y en avoir 6 de plus... soit 18... ce qui n'est pas très loin !!!
<br />
>>>>>>> ca0e7094056054aecad42ff0a001ae43710074c3
<br />


# Problem 2 :<br />
<br />
Lors de multiple simulation, on a 1 seul atome d'argent qui s'incruste (40 et 100 iterations).<br />
Tester avec Cu-Ag et Cu-Ni
